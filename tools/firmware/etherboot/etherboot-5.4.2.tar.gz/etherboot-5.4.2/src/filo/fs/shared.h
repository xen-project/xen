/* Sorry, nothing is shared here ;) Just for GRUB compatibility. */
