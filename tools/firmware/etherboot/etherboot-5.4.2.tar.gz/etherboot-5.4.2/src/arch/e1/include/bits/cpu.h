#ifndef E1_BITS_CPU_H
#define E1_BITS_CPU_H

#define cpu_setup() do {} while(0)

#endif /* E1_BITS_CPU_H */
