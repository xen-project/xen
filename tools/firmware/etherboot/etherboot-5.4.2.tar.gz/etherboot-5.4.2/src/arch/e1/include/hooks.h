#ifndef ETHERBOOT_E1_HOOKS_H
#define ETHERBOOT_E1_HOOKS_H

#define arch_main(data,params) do {} while(0)
#define arch_on_exit(status) do {} while(0)
#define arch_relocate_to(addr) do {} while(0)
#define arch_relocated_from(old_addr) do {} while(0)

#endif /* ETHERBOOT_E1_HOOKS_H */
