#ifndef E1_BITS_ELF_H
#define E1_BITS_ELF_H

/* dummy file, needed for the compilation of core/nic.c */

#endif /* E1_BITS_ELF_H */
