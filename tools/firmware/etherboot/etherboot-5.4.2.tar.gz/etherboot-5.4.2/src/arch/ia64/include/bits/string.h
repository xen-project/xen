#ifndef ETHERBOOT_BITS_STRING_H
#define ETHERBOOT_BITS_STRING_H

/* define inline optimized string functions here */

#endif /* ETHERBOOT_BITS_STRING_H */
