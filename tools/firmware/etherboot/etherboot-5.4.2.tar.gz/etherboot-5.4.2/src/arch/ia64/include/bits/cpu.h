#ifndef IA64_BITS_CPU_H
#define IA64_BITS_CPU_H

#define cpu_setup() do {} while(0)

#endif /* IA64_BITS_CPU_H */
