#ifndef _USR_WOL_H
#define _USR_WOL_H

/** @file
 *
 * Wakeon lan
 *
 */

extern void wakeup_server(char *);

#endif /* _USR_WOL_H */
