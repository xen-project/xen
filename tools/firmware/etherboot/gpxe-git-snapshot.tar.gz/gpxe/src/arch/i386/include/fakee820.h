#ifndef _FAKEE820_H
#define _FAKEE820_H

extern void fake_e820 ( void );
extern void unfake_e820 ( void );

#endif /* _FAKEE820_H */
