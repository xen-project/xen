#ifndef _BITS_UACCESS_H
#define _BITS_UACCESS_H

#include <realmode.h>

#endif /* _BITS_UACCESS_H */
