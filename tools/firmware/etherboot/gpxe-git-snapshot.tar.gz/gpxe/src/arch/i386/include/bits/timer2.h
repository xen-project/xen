#ifndef BITS_TIMER2_H
#define BITS_TIMER2_H

#include <stddef.h>

void i386_timer2_udelay(unsigned int usecs);

#endif
