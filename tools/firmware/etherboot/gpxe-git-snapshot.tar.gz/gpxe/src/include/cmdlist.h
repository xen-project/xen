#ifndef COMMANDLIST_H
#define COMMANDLIST_H

void test_req();
void test2_req();
void help_req();
void nvo_cmd_req();

void commandlist()
{
	//	test_req();
	//	test2_req();
	help_req();
	nvo_cmd_req();
}

#endif

