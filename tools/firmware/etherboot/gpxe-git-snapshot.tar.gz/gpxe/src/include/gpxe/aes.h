#ifndef _GPXE_AES_H
#define _GPXE_AES_H

struct crypto_algorithm;

extern struct crypto_algorithm aes_algorithm;

#endif /* _GPXE_AES_H */
