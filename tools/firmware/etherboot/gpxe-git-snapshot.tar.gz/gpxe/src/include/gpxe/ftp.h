#ifndef _GPXE_FTP_H
#define _GPXE_FTP_H

/** @file
 *
 * File transfer protocol
 *
 */

/** FTP default port */
#define FTP_PORT 21

#endif /* _GPXE_FTP_H */
