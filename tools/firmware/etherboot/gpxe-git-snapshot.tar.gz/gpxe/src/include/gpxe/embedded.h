#ifndef _GPXE_EMBEDDED_H
#define _GPXE_EMBEDDED_H

#include <gpxe/image.h>

struct image *embedded_image(void);

#endif

